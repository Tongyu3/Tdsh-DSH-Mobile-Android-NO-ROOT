# dsh-android-env

往 DSH 的系统提示词里注入一段**运行环境说明**，让模型知道自己在安卓手机上、
在 proot 容器里，以及这台设备有哪些专属工具。

## 解决什么问题

DSH 内核是跨平台的，默认提示词按"通用服务器"写。到了手机上就会反复出现这类错：

- 用 `systemctl` 想让进程常驻（容器里没有 systemd）
- 以为有图形界面
- 以为 `apt` / `sudo` 能拿到真正的 root（proot 的 `-0` 只是伪装身份）
- 不知道 `phone_*` 那批工具存在，宁可自己瞎猜怎么操作手机
- 装 npm 包时写死官方源，在大陆网络下必然超时

这段说明就是把这些一次性讲清楚。

## 机制

用的是 DSH 预设插件通用的 `systemPrompt.section()`：

```js
ctx.systemPrompt.section({
  name: 'dsh-android-env:host',   // 唯一名，带前缀防撞
  order: 150,                      // 越大越靠后
  text: () => buildText(),         // 函数：每轮重新求值，能反映此刻状态
})
```

`text` 传函数而不是字符串，是为了把**内核版本 / Node 版本 / 当前 npm 源**
这类会变的信息带上；写死字符串的话升级内核后说明就过期了。

## 自检

加载后会写 `/sdcard/.dsh-phone/plugin-loaded-android-env.txt`。
这个项目栽过一次"加载了 ≠ 生效了"，所以每个插件都留一份可读的痕迹。

## 依赖

无。容器常常是离线的，多一个依赖就多一个装不上的理由。
