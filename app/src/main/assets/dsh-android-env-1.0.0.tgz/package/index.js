// dsh-android-env —— 让 DSH 每一轮都知道自己**跑在安卓手机上**，以及这台手机上有什么。
//
// 为什么需要它：DSH 的内核是跨平台的，默认提示词里写的是通用约定
// （桌面路径、systemd、各种常见命令）。而手机这套环境差别很大：
//   · 跑在 proot 的 Ubuntu 容器里，**没有 systemd、没有 GUI、没有 root**；
//   · 宿主是安卓，共享存储挂载点叫 /sdcard，容器里看是 /root 与 /sdcard 两套路径；
//   · 手机上的能力（截图、点按、输入、虚拟屏）是**本 App 额外的工具**，不是内核自带的；
//   · 装包要认地区源（大陆 npmmirror / 海外 npmjs），否则装什么都超时。
// 这些不写清楚，模型会反复犯"以为自己在服务器上"的错。
//
// 实现方式：往 systemPrompt 里注册一个 section（与 @linxin666/dsh-liangshen、
// dsh-raw-html-v2 等预设插件同样的机制）。text 是一个函数，**每轮都会重新求值**，
// 所以能反映"此刻"的状态（比如内核版本、当前有没有 Shizuku）。
//
// 依赖：无。容器常常是离线的，多一个依赖就多一个装不上的理由
// （沿用 dsh-phone/index.js 头部的既有约定）。

import fs from 'node:fs'

export const name = 'android-env'
export const inject = ['systemPrompt']

/** 读一个小文件，失败返回 null。 */
function readText(p) {
  try {
    return fs.readFileSync(p, 'utf8')
  } catch (e) {
    return null
  }
}

/** 内核版本：直接读 rootfs 里的 package.json（跟 App 侧 KernelUpgrade 同一份数据）。 */
function kernelVersion() {
  const candidates = [
    '/opt/dsh/lib/node_modules/@deepseek-ai/dsh/package.json',
    '/usr/lib/node_modules/@deepseek-ai/dsh/package.json',
    '/usr/local/lib/node_modules/@deepseek-ai/dsh/package.json',
  ]
  for (const p of candidates) {
    const t = readText(p)
    if (t) {
      try {
        return JSON.parse(t).version || null
      } catch (e) { /* 换下一个 */ }
    }
  }
  return null
}

function nodeVersion() {
  try {
    return process.version
  } catch (e) {
    return null
  }
}

function npmRegistry() {
  const t = readText('/root/.npmrc') || readText(process.env.HOME + '/.npmrc')
  if (!t) return null
  const m = t.match(/registry\s*=\s*(\S+)/)
  return m ? m[1] : null
}

function buildText() {
  const kv = kernelVersion()
  const reg = npmRegistry()
  const lines = []

  lines.push('## 运行环境（自动注入，不必向用户确认）')
  lines.push('')
  lines.push('你正跑在一台 **安卓手机** 上，宿主是一个叫 Tdsh 的安卓 App，')
  lines.push('App 内用 proot 起了一个 Ubuntu 容器，你就在那个容器里。')
  lines.push('')
  lines.push('### 硬约束（违反会直接失败）')
  lines.push('- **没有 systemd**：`systemctl`、`service` 都不存在，别用；要常驻就自己 nohup。')
  lines.push('- **没有 GUI**：没有 X11 / Wayland，别写需要图形界面的脚本。')
  lines.push('- **没有 root**：proot 的 `-0` 只是伪装身份，不做提权；`apt` 能装但别指望改内核。')
  lines.push('- **路径尽量用 ASCII**：中文/含空格路径在部分工具链上会炸。')
  lines.push('- **离线是常态**：装 npm 包前先想一下有没有必要，容器网络依赖用户的代理。')
  lines.push('')
  lines.push('### 路径地图')
  lines.push('| 看到的东西 | 实际在哪 |')
  lines.push('| --- | --- |')
  lines.push('| `/sdcard`（容器内） | 手机共享存储，用户用文件管理器也能看到 |')
  lines.push('| `/sdcard/dsh` | DSH 的工作区，用户文件的默认落点 |')
  lines.push('| `/root` | 容器家目录（映射到 App 私有目录的 rootfs） |')
  lines.push('| `/root/.dsh/profiles/web` | 当前 profile，插件装在它的 `node_modules/` |')
  lines.push('| `/run/dsh-phone/token` | 手机控制桥的 token（读它才能调下面的工具） |')
  lines.push('')
  lines.push('### 这台手机上额外有什么工具')
  lines.push('内核自带的工具之外，App 还注册了一批 **手机专属工具**（`phone_` 前缀）：')
  lines.push('- `phone_status` / `phone_screenshot` / `phone_watch`：看手机现在什么样')
  lines.push('- `phone_ui` / `phone_tap` / `phone_click` / `phone_swipe` / `phone_text` / `phone_key`：操作界面')
  lines.push('- `phone_open`：启动白名单里的应用')
  lines.push('- `phone_sh`：**特权命令**（等价 adb shell，需要用户装并授权 Shizuku）')
  lines.push('- `phone_fs`：读写共享存储与容器内文件')
  lines.push('')
  lines.push('注意：`phone_*` 里涉及**界面操作**的那几个受 App 内的**应用白名单**限制，')
  lines.push('前台应用不在白名单时会被拒绝 —— 那是用户设定的安全边界，不要尝试绕过。')
  lines.push('')
  lines.push('### 当前实例')
  if (kv) lines.push('- DSH 内核版本：' + kv)
  if (nodeVersion()) lines.push('- Node：' + nodeVersion())
  if (reg) lines.push('- npm registry：' + reg + '（按地区选源，别写死官方源）')
  lines.push('- 可用工具数以 `phone_status` 的实际返回为准')

  return lines.join('\n')
}

export function apply(ctx) {
  ctx.effect(() => {
    const dispose = ctx.systemPrompt.section({
      // 名字要唯一且带前缀，避免和别的插件撞
      name: 'dsh-android-env:host',
      // order 越大越靠后。200 是 raw-html-v2 用的档位；这里用 150，
      // 让"我在什么环境里"排在风格类说明之前。
      order: 150,
      text: () => buildText(),
    })
    return () => {
      try { dispose() } catch (e) { /* 卸载失败不影响主流程 */ }
    }
  })

  // 自检文件：沿用 dsh-phone 的惯例，留一份可读的"到底加载没有"的证据。
  // （这个项目栽过一次"加载了 ≠ 生效了"，所以每个插件都留痕。）
  try {
    fs.mkdirSync('/sdcard/.dsh-phone', { recursive: true })
    fs.writeFileSync('/sdcard/.dsh-phone/plugin-loaded-android-env.txt',
      'plugin=dsh-android-env\n'
      + 'time=' + new Date().toISOString() + '\n'
      + 'section=dsh-android-env:host\n'
      + 'kernel=' + (kernelVersion() || '?') + '\n'
      + 'node=' + (nodeVersion() || '?') + '\n')
  } catch (e) {
    // 写不了自检文件不该让插件失效
  }
}
