// dsh-thinking —— 思考链治理：先**探明**能挂哪个钩子，再谈删不删。
//
// ────────────────────────────────────────────────────────────────
// 为什么这个插件第一步是"探针"而不是"开关"
// ────────────────────────────────────────────────────────────────
// 上一轮的教训（用户自己验证过的结论）：
//   有人想通过包 `llm.stream` 来改发出去的请求，结果**那个方法从来没被调用过** ——
//   请求路径是"门面 → 适配器"，插件看到的那一层只是门面；打包之后字段名还被压缩混淆，
//   运行期根本拦不到。最后只能改内核源码，而用户不愿意为此改内核。
//
// 所以这里**不猜**：先提供一个探针工具，把运行时**实际存在**的方法与字段 dump 成
// 一个 JSON 交给用户/开发者看。根据探明结果再决定走哪条路：
//
//   甲）探到请求级钩子（比如 llm 上有可注册的 middleware / transform）
//       → 在那里剥离 thinking，覆盖全部会话，最干净。
//   乙）探不到，但 `sessions` 可读可写
//       → 退到会话说：把存下来的 thinking 块删掉，这样重放时本来就无思考可放
//          （内核组装历史时会重放思考链，源头干净了，重放也就干净了）。
//   丙）都探不到
//       → 老老实实只交付"诊断"：报告每个会话的思考链占用，不提供假开关。
//
// 三种情况下，"诊断"这一半都是有用的，所以先把它做扎实。
//
// 依赖：无。
import fs from 'node:fs'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'thinking'
// 只注入 tools：llm / sessions 用**可选方式**取（见 probeCtx），
// 因为它们在不同内核版本上不一定存在 —— 一旦写进 inject，缺一个插件就整个不加载，
// 连"诊断"都拿不到，那是最坏的结果。
export const inject = ['tools']

const HUD_DIR = '/sdcard/.dsh-phone'
const PROBE_FILE = HUD_DIR + '/thinking-probe.json'

/** 反射出一个对象上所有可用的方法名（含原型链，深度有限）。 */
function methodsOf(obj, limit = 120) {
  const out = []
  if (!obj) return out
  let o = obj
  let depth = 0
  while (o && o !== Object.prototype && depth < 4) {
    for (const k of Object.getOwnPropertyNames(o)) {
      if (k === 'constructor') continue
      let kind = '?'
      try {
        kind = typeof o[k]
      } catch (e) { kind = 'throws' }
      if (!out.some((x) => x.name === k)) out.push({ name: k, kind })
      if (out.length >= limit) return out
    }
    o = Object.getPrototypeOf(o)
    depth++
  }
  return out
}

/** 安全取一个服务；不存在返回 null 而不是抛。 */
function probeCtx(ctx, key) {
  try {
    return ctx && ctx[key] ? ctx[key] : null
  } catch (e) {
    return null
  }
}

/** 递归数一数 JSON 里有多少 thinking 块（内核的历史里通常叫 thinking / reasoning）。 */
function countThinking(node, acc, depth) {
  if (depth > 24 || node === null || node === undefined) return
  if (Array.isArray(node)) {
    for (const it of node) countThinking(it, acc, depth + 1)
    return
  }
  if (typeof node !== 'object') return
  for (const [k, v] of Object.entries(node)) {
    const lk = k.toLowerCase()
    if (lk === 'thinking' || lk === 'reasoning' || lk === 'thought') {
      if (typeof v === 'string') {
        acc.blocks++
        acc.chars += v.length
      } else if (v) {
        acc.blocks++
      }
    }
    if (lk.includes('thinking') || lk.includes('reasoning')) acc.keys.push(k)
    countThinking(v, acc, depth + 1)
  }
}

export function apply(ctx) {
  const tools = [
    defineTool({
      name: 'thinking_probe',
      description: '探测这台设备上的 DSH 运行时**实际**暴露了哪些与请求/会话相关的接口，'
        + '并把结果写成 JSON（/sdcard/.dsh-phone/thinking-probe.json）。'
        + '目的是搞清楚"到底能不能从插件侧拦到发出去的请求"，'
        + '而不是像上次那样凭猜测去包 llm.stream（实测那层是门面，根本不会被调用）。'
        + '排查思考链问题、或做任何"改请求"的插件之前，先跑这个。',
      parameters: {},
      output: {
        schema: { type: 'string' },
        render: (_a, v) => [{ type: 'text', text: String(v) }],
      },
      async execute() {
        const report = {
          at: new Date().toISOString(),
          node: process.version,
          ctxKeys: [],
          services: {},
          notes: [],
        }

        try {
          report.ctxKeys = methodsOf(ctx, 200).map((m) => m.name)
        } catch (e) {
          report.notes.push('列举 ctx 失败: ' + e)
        }

        for (const key of ['llm', 'sessions', 'agent', 'agents', 'invariants', 'tools']) {
          const svc = probeCtx(ctx, key)
          if (!svc) {
            report.services[key] = null
            continue
          }
          report.services[key] = { present: true, members: methodsOf(svc, 150) }
        }

        // 顺手看看会话目录，拿到"思考链现在占多少"
        const dirs = [
          '/root/.dsh/sessions',
          '/root/.dsh/dsh-session-archive',
          (process.env.HOME || '/root') + '/.dsh/sessions',
        ]
        report.sessionDirs = []
        for (const d of dirs) {
          try {
            if (!fs.existsSync(d)) continue
            const files = fs.readdirSync(d).slice(0, 400)
            let bytes = 0
            for (const f of files) {
              try { bytes += fs.statSync(path.join(d, f)).size } catch (e) { /* 跳过 */ }
            }
            report.sessionDirs.push({ dir: d, files: files.length, bytes })
          } catch (e) { /* 跳过 */ }
        }

        try {
          fs.mkdirSync(HUD_DIR, { recursive: true })
          fs.writeFileSync(PROBE_FILE, JSON.stringify(report, null, 2))
        } catch (e) {
          report.notes.push('写探针文件失败: ' + e)
        }

        const svcLine = Object.entries(report.services)
          .map(([k, v]) => '  ' + k + ': ' + (v ? v.members.length + ' 个成员' : '（不存在）'))
          .join('\n')
        return '探针完成，已写入 ' + PROBE_FILE + '\n\n'
          + 'ctx 上的服务数：' + report.ctxKeys.length + '\n'
          + '关键服务：\n' + svcLine + '\n\n'
          + '（把这个 JSON 发回来看结果，再决定思考链怎么治理）'
      },
    }),

    defineTool({
      name: 'thinking_report',
      description: '统计会话里思考链的占用情况：多少块、多少字符。'
        + '用来回答"上下文为什么涨这么快""思考链到底占多少"这类问题。'
        + '只读，不改任何东西。',
      parameters: {
        dir: { type: 'string', description: '会话目录，默认自动找' },
        limit: { type: 'number', description: '最多看几个文件，默认 50' },
      },
      output: {
        schema: { type: 'string' },
        render: (_a, v) => [{ type: 'text', text: String(v) }],
      },
      async execute(args) {
        const dir = args && args.dir
          ? String(args.dir)
          : ['/root/.dsh/sessions', (process.env.HOME || '/root') + '/.dsh/sessions']
              .find((d) => { try { return fs.existsSync(d) } catch (e) { return false } })
        if (!dir) return '没找到会话目录。用 thinking_probe 看看这台机器上会话到底存在哪。'

        const max = Math.max(1, Math.min(400, Number(args && args.limit) || 50))
        let files = []
        try {
          files = fs.readdirSync(dir).filter((f) => !f.startsWith('.')).slice(0, max)
        } catch (e) {
          return '读不了 ' + dir + '：' + e
        }

        const agg = { blocks: 0, chars: 0, keys: [] }
        let seen = 0
        for (const f of files) {
          try {
            const big = fs.statSync(path.join(dir, f)).size > 32 * 1024 * 1024
            if (big) continue
            const t = fs.readFileSync(path.join(dir, f), 'utf8')
            for (const line of t.split('\n')) {
              if (!line.trim()) continue
              try { countThinking(JSON.parse(line), agg, 0) } catch (e) { /* 非 JSON 行跳过 */ }
            }
            seen++
          } catch (e) { /* 跳过坏文件 */ }
        }
        const uniq = Array.from(new Set(agg.keys)).slice(0, 10)
        return '会话目录: ' + dir + '\n'
          + '读了 ' + seen + ' / ' + files.length + ' 个文件\n\n'
          + '思考链块数: ' + agg.blocks + '\n'
          + '思考链字符: ' + agg.chars
          + (agg.chars > 0 ? '（约 ' + Math.round(agg.chars / 4) + ' token 粗估）' : '') + '\n'
          + (uniq.length ? '命中的字段名: ' + uniq.join(', ') + '\n' : '')
          + '\n这只说明"存下来了多少"，不等于"每轮都重发多少"——'
          + '实际重发量取决于内核组装历史时的裁剪策略。'
      },
    }),

    defineTool({
      name: 'thinking_policy',
      description: '思考链政策：查状态、或（在探明钩子可用后）执行清理。'
        + '**目前只有 status 会真的干活**：strip 需要先跑 thinking_probe 确认钩子，'
        + '拿到结果再决定实现方式 —— 不做"看起来能用其实不生效"的开关。',
      parameters: {
        op: {
          type: 'string',
          enum: ['status', 'strip'],
          description: '要执行的操作，默认 status',
        },
      },
      output: {
        schema: { type: 'string' },
        render: (_a, v) => [{ type: 'text', text: String(v) }],
      },
      async execute(args) {
        const op = (args && args.op) ? String(args.op) : 'status'
        const probeExists = (() => { try { return fs.existsSync(PROBE_FILE) } catch (e) { return false } })()
        if (op === 'status') {
          return '思考链政策\n'
            + '  模式      : 观察（尚未启用任何改写）\n'
            + '  探针结果  : ' + (probeExists ? '已有' : '还没有，先跑 thinking_probe') + '\n'
            + '  可用钩子  : 以探针结果为准\n\n'
            + '为什么还没直接给开关：上一轮实测证明"包 llm.stream"这条路是死的'
            + '（插件看到的只是门面，适配器那层拦不到）。在没有探明真正可用的钩子之前'
            + '提供一个开关，只会让人以为它在生效。'
        }
        if (op === 'strip') {
          return 'ERROR 还不能执行 strip。\n\n'
            + '原因：需要先用 thinking_probe 确认这台设备上到底哪个接口可写，\n'
            + '再按结果实现（请求级 / 会话级两条路，见插件 README）。\n'
            + '在那之前硬做，就是上一轮那个"没生效但看起来生效"的坑。'
        }
        return 'ERROR 未知 op: ' + op
      },
    }),
  ]

  let ok = 0
  const failed = []
  for (const t of tools) {
    try {
      ctx.tools.register(t)
      ok++
    } catch (e) {
      failed.push(t.name + ': ' + (e && e.message ? e.message : String(e)))
    }
  }

  // 自检文件（沿用 dsh-phone 的"加载了 ≠ 生效了"惯例）
  try {
    fs.mkdirSync(HUD_DIR, { recursive: true })
    fs.writeFileSync(HUD_DIR + '/plugin-loaded-thinking.txt',
      'plugin=dsh-thinking\n'
      + 'time=' + new Date().toISOString() + '\n'
      + 'tools=' + tools.length + '\n'
      + 'registered=' + ok + '\n'
      + 'failed=' + JSON.stringify(failed) + '\n'
      + 'names=' + tools.map((t) => t.name).join(',') + '\n')
  } catch (e) {
    // 写不了自检文件不该让插件失效
  }
}
