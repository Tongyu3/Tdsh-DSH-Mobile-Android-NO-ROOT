# dsh-thinking

思考链治理插件。**当前形态是"探针 + 诊断"，不是"一键删除"。**

## 为什么不是一上来就给开关

用户之前验证过一条结论，值得原样记住：

> 想通过包 `llm.stream` 来改发出去的请求 —— **那个方法从来没被调用过**。
> 请求路径是"门面 → 适配器"，插件看到的那一层只是门面；
> 打包之后字段名还被压缩混淆，运行期根本拦不到。
> 结论：只能改内核源码，而用户不想为此改内核。

所以本插件**不猜钩子**。流程是：

1. 跑 `thinking_probe` —— 把运行时**实际存在**的方法与字段 dump 成
   `/sdcard/.dsh-phone/thinking-probe.json`，看 JSON 说话。
2. 按探明结果选路：
   - **甲）探到请求级钩子**（`llm` 上有可注册的 middleware / transform）
     → 在那里剥离 `thinking`，覆盖全部会话，最干净。
   - **乙）探不到请求级，但 `sessions` 可读可写**
     → 退到会话层：把存下来的 `thinking` 块删掉。内核组装历史时会重放思考链，
       源头干净了，重放也就干净了。
   - **丙）都探不到**
     → 只交付诊断，**不提供假开关**。
3. 诊断这一半（`thinking_report`）在三种情况下都有用，所以先做扎实。

## 三个工具

| 工具 | 作用 |
|---|---|
| `thinking_probe` | 探测运行时接口，写 JSON。**排查任何"改请求"的问题前先跑它** |
| `thinking_report` | 统计会话里思考链的块数与字符数（只读） |
| `thinking_policy` | `status` 看当前模式；`strip` 在钩子探明之前会明确拒绝执行 |

## 自检

`/sdcard/.dsh-phone/plugin-loaded-thinking.txt`

## 依赖

无（只 import `@deepseek-ai/dsh-tools` 的 `defineTool`，那是内核自带的）。
